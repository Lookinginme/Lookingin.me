import openai
import requests

# 🔐 Replace with your actual OpenAI key
openai.api_key = "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

"

def generate_openai_mp3(text, file_name="nurse_betty.mp3", voice="nova"):
    response = openai.audio.speech.create(
        model="tts-1",
        voice=voice,
        input=text
    )

    # Save MP3 response directly
    with open(file_name, "wb") as f:
        f.write(response.content)

    print(f"✅ MP3 saved as: {file_name}")

# 🧪 Test it
generate_openai_mp3("Hi there, I’m Nurse Betty. I'm here to help you live fully with Type 1 Diabetes.")
